import 'package:flutter/material.dart';

void main() {
  runApp(WhatsAppClone());
}

class WhatsAppClone extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFF128C7E), // WhatsApp Green
        secondaryHeaderColor: Color(0xFF128C7E), // WhatsApp Dark Green
      ),
      home: WhatsAppHome(),
    );
  }
}

class WhatsAppHome extends StatefulWidget {
  @override
  _WhatsAppHomeState createState() => _WhatsAppHomeState();
}

class _WhatsAppHomeState extends State<WhatsAppHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("WhatsApp"),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              // Handle search action
            },
          ),
          IconButton(
            icon: Icon(Icons.more_vert),
            onPressed: () {
              // Handle more options action
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: chatData.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(chatData[index]['avatarUrl']!),
            ),
            title: Text(chatData[index]['name']!),
            subtitle: Text(chatData[index]['message']!),
            trailing: Text(chatData[index]['time']!),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Handle new chat action
        },
        child: Icon(Icons.message),
        backgroundColor: Theme.of(context).secondaryHeaderColor,
      ),
    );
  }
}

List<Map<String, String>> chatData = [
  {
    'name': 'Aliyah',
    'message': 'What\'s up?',
    'time': '10:30 AM',
    'avatarUrl': 'https://example.com/avatar1.jpg',
  },
  {
    'name': 'Anoushaaa',
    'message': 'What\'s up?',
    'time': '11:45 AM',
    'avatarUrl': 'https://example.com/avatar2.jpg',
  },
  {
    'name': 'Asiaa',
    'message': 'What\'s up?',
    'time': '1:20 PM',
    'avatarUrl': 'https://example.com/avatar3.jpg',
  },
  {
    'name': 'Ali',
    'message': 'What\'s up?',
    'time': '2:15 PM',
    'avatarUrl': 'https://example.com/avatar4.jpg',
  },
  {
    'name': 'saad',
    'message': 'Not much, just working on a project.',
    'time': '3:00 PM',
    'avatarUrl': 'https://example.com/avatar5.jpg',
  },
  // Add more chat data here...
];

import 'package:flutter/material.dart';

import 'details.dart';

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Home Page")),
      body: Column(
        children: [
          const Text("\t\t\tHeyaaa it meeeeeeee\n"),
          ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (context) => DetailsPage(),
                ));
              },
              child: const Text("Click"))
        ],
      ),
    );
  }
}

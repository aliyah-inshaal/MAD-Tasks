import 'package:flutter/material.dart';

import 'main.dart';

class DetailsPage extends StatelessWidget {
  const DetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Details page")),
      body: Column(
        children: [
          const Text("\t\t\tThis is details pageeeee\n"),
          ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => MyApp(),
                ));
              },
              child: const Text("Click"))
        ],
      ),
    );
  }
}
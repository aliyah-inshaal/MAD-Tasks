import 'package:flutter/material.dart';

class MultipleGesturesDemo extends StatefulWidget {
  @override
  _MultipleGesturesDemoState createState() => _MultipleGesturesDemoState();
}

class _MultipleGesturesDemoState extends State<MultipleGesturesDemo> {
  String gestureMessage = 'No Gesture Detected';

  void _handleTap() {
    setState(() {
      gestureMessage = 'Tapped!';
    });
  }

  void _handleDoubleTap() {
    setState(() {
      gestureMessage = 'Double Tapped!';
    });
  }

  void _handleLongPress() {
    setState(() {
      gestureMessage = 'Long Pressed!';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Multiple Gestures Demo'),
      ),
      body: Center(
        child: GestureDetector(
          onTap: _handleTap,
          onDoubleTap: _handleDoubleTap,
          onLongPress: _handleLongPress,
          child: Container(
            width: 200,
            height: 200,
            color: Colors.blue,
            alignment: Alignment.center,
            child: Text(
              gestureMessage,
              style: TextStyle(fontSize: 20, color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: MultipleGesturesDemo(),
  ));
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'todo.dart';
class TodosProvider extends ChangeNotifier {
 List<Todo> _todos = [];
 List<Todo> get todos => _todos;
 void addTodo(Todo todo) {
 _todos.add(todo);
 notifyListeners();
 }
 void toggleTodo(int index) {
 _todos[index].isDone = !_todos[index].isDone;
 notifyListeners();
 }
 void deleteTodo(int index) {
 _todos.removeAt(index);
 notifyListeners();
 }
}

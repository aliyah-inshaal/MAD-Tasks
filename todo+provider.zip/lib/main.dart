import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo/todo.dart';
import 'package:todo/todos_provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => TodosProvider(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Provider Todo App',
      home: TodoListScreen(),
    );
  }
}

class TodoListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Provider Todo App'),
      ),
      body: ListView.builder(
        itemCount: context.watch<TodosProvider>().todos.length,
        itemBuilder: (context, index) {
          final todo = context.watch<TodosProvider>().todos[index];
          return ListTile(
            title: Text(todo.title),
            leading: Checkbox(
              value: todo.isDone,
              onChanged: (_) {
                context.read<TodosProvider>().toggleTodo(index);
              },
            ),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                context.read<TodosProvider>().deleteTodo(index);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Show a dialog to add a new todo
          showDialog(
            context: context,
            builder: (context) => NewTodoDialog(),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class NewTodoDialog extends StatefulWidget {
  @override
  _NewTodoDialogState createState() => _NewTodoDialogState();
}

class _NewTodoDialogState extends State<NewTodoDialog> {
  final TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Add New Todo'),
      content: TextField(
        controller: _controller,
        decoration: InputDecoration(hintText: 'Enter your todo...'),
      ),
      actions: <Widget>[
        TextButton(
          child: Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: Text('Add'),
          onPressed: () {
            final newTodoText = _controller.text.trim();
            if (newTodoText.isNotEmpty) {
              final newTodo = Todo(title: newTodoText);
              context.read<TodosProvider>().addTodo(newTodo);
              Navigator.of(context).pop();
            }
          },
        ),
      ],
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
